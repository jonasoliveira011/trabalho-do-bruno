<html>

<head>

</head>

<body>
    <table>
        <thead>
            <th>NOME</th>
            <th>CPF PROFISSIONAL</th>
            <th>DATA NASCIMENTO</th>
            <th>TELEFONE</th>
            <th>EMAIL</th>
            <th>AÇÕES</th>
        </thead>
        <tbody>
            <?php
            include 'conexao.php';

            $selecionar = 'SELECT * FROM profissionais';
            $resultado = mysqli_query($conexao, $selecionar) or die('query failed:' . mysqli_error(die));

            while ($linha = mysqli_fetch_array($resultado, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?= $linha["nome"] ?></td>
                    <td><?= $linha["cpf_prof"] ?></td>
                    <td><?= $linha["data_nasc"] ?></td>
                    <td><?= $linha["fone"] ?></td>
                    <td><?= $linha["email_prof"] ?></td>

                    <td><a href='deletar_prof.php?id=<?php echo $linha["prof_id"] ?>&action=delete'>DELETAR</a></td>
                    <td><a href='index.php?id=<?php echo $linha["prof_id"] ?>&action=update_profissionais'>UPDATE</a></td>
                </tr>
            <?php
            }
            mysqli_close($conexao);
            ?>
        </tbody>

    </table>
</body>

</html>