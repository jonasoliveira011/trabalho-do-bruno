-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Nov-2022 às 01:15
-- Versão do servidor: 10.4.25-MariaDB
-- versão do PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `vigilancia_db`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `auto_termo`
--

CREATE TABLE `auto_termo` (
  `id` int(30) NOT NULL,
  `lei` float NOT NULL,
  `classif_lei` varchar(255) NOT NULL,
  `conclusao` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `dadosestabelecimento`
--

CREATE TABLE `dadosestabelecimento` (
  `dadosest_id` int(30) NOT NULL,
  `razao_soc` varchar(255) NOT NULL,
  `nome_fant` varchar(255) NOT NULL,
  `inscricao_mun` float NOT NULL,
  `inscricao_est` float NOT NULL,
  `phone` int(30) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `estabelecimento`
--

CREATE TABLE `estabelecimento` (
  `estabelecimento_id` int(30) NOT NULL,
  `estabelecimentos` varchar(255) NOT NULL,
  `identificacao` varchar(255) NOT NULL,
  `irregularidade` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `nivel_estab`
--

CREATE TABLE `nivel_estab` (
  `nivel_id` int(30) NOT NULL,
  `nivel_risco` varchar(20) NOT NULL,
  `data_min` date NOT NULL,
  `data_max` date NOT NULL,
  `codigo` int(20) NOT NULL,
  `descricao_ativ` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `profissionais`
--

CREATE TABLE `profissionais` (
  `prof_id` int(11) NOT NULL,
  `nome` varchar(220) NOT NULL,
  `cpf_prof` int(20) NOT NULL,
  `data_nasc` date NOT NULL,
  `fone` int(30) NOT NULL,
  `email_prof` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `auto_termo`
--
ALTER TABLE `auto_termo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dadosestabelecimento`
--
ALTER TABLE `dadosestabelecimento`
  ADD PRIMARY KEY (`dadosest_id`);

--
-- Índices para tabela `estabelecimento`
--
ALTER TABLE `estabelecimento`
  ADD PRIMARY KEY (`estabelecimento_id`);

--
-- Índices para tabela `nivel_estab`
--
ALTER TABLE `nivel_estab`
  ADD PRIMARY KEY (`nivel_id`);

--
-- Índices para tabela `profissionais`
--
ALTER TABLE `profissionais`
  ADD PRIMARY KEY (`prof_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `auto_termo`
--
ALTER TABLE `auto_termo`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `dadosestabelecimento`
--
ALTER TABLE `dadosestabelecimento`
  MODIFY `dadosest_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `estabelecimento`
--
ALTER TABLE `estabelecimento`
  MODIFY `estabelecimento_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `nivel_estab`
--
ALTER TABLE `nivel_estab`
  MODIFY `nivel_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `profissionais`
--
ALTER TABLE `profissionais`
  MODIFY `prof_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
