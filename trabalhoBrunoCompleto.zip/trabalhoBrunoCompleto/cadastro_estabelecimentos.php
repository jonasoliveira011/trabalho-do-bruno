<?php

$estabelecimento = isset($_POST["estabelecimento"]) ? $_POST["estabelecimento"] : null;

$identificacao = isset($_POST["ident_setor"]) ? $_POST["ident_setor"] : null;

$irregularidades = isset($_POST["irregularidades"]) ? $_POST["irregularidades"] : null;


if ($estabelecimento != "" and $identificacao != "" and $irregularidades != "") {
    include 'conexao.php';

    $query = 'INSERT INTO estabelecimento(estabelecimentos,identificacao,irregularidade)
     VALUES ("' . $estabelecimento . '","' . $identificacao . '","' . $irregularidades . '")';
    $result = mysqli_query($conexao, $query) or die('query failed:' . mysqli_error(die));
    mysqli_close($conexao);
?>
    <script>
        window.alert("Seu cadastro foi enviado com sucesso");
        window.location.href = 'index.php';
    </script>
<?php
}

?>

<a href="index.php">Voltar</a>