<?php
include 'conexao.php';
$deletar = 'DELETE FROM estabelecimento WHERE estabelecimento_id=' . $_GET["id"];
$resultado = mysqli_query($conexao, $deletar) or die('QUERY FAILED:' . mysqli_error());

mysqli_close($conexao);
?>

<script>
    window.alert("Seu cadastro foi deletado com sucesso");
    window.location.href = 'index.php';
</script>
<?php
?>
<a href="index.php">Voltar</a>