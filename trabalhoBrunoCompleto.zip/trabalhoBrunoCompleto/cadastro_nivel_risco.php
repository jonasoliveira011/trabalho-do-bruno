<?php

$risco = isset($_POST["risco_clas"]) ? $_POST["risco_clas"] : null;

$data_min = isset($_POST["datemin"]) ? $_POST["datemin"] : null;

$data_max = isset($_POST["datemax"]) ? $_POST["datemax"] : null;

$codigo = isset($_POST["codigo"]) ? $_POST["codigo"] : null;

$descricao = isset($_POST["descricao"]) ? $_POST["descricao"] : null;

if ($risco != "" and $data_min != "" and $data_max != "" and $codigo != "" and $descricao != "") {
    include 'conexao.php';

    $query = 'INSERT INTO nivel_estab(nivel_risco,data_min,data_max,codigo,descricao_ativ)
     VALUES ("' . $risco . '","' . $data_min . '","' . $data_max . '","' . $codigo . '","' . $descricao . '")';
    $result = mysqli_query($conexao, $query) or die('query failed:' . mysqli_error(die));
    mysqli_close($conexao);
?>
    <script>
        window.alert("Seu cadastro foi enviado com sucesso");
        window.location.href = 'index.php';
    </script>
<?php
}

?>

<a href="index.php">Voltar</a>