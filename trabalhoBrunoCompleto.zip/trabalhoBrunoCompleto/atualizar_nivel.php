<?php   
    include 'conexao.php';

    $id_nivel_estab = $_GET["id"];
    $action_nivel = "execute-update_nivel";

    $select = 'SELECT nivel_risco,data_min,data_max,codigo,descricao_ativ FROM nivel_estab WHERE nivel_id= '.$_GET["id"];
    $resultado = mysqli_query($conexao,$select) or die ("query failed:".mysqli_error());

    $coluna = mysqli_fetch_row($resultado);
    mysqli_close($conexao);

    $risco = $coluna[0];
    $data_min = $coluna[1];
    $data_max = $coluna[2];
    $codigo = $coluna[3];
    $descricao = $coluna[4];

?>