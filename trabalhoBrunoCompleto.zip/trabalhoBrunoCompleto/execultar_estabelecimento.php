<?php
include 'conexao.php';

$execultar = 'UPDATE estabelecimento SET estabelecimentos="' . $_POST["estabelecimento"] . '",
identificacao="' . $_POST["ident_setor"] . '",
irregularidade="' . $_POST["irregularidades"] . '" WHERE estabelecimento_id= ' . $_POST["id"];

$resultado = mysqli_query($conexao, $execultar)
    or die('query failed:' . mysqli_error());

mysqli_close($conexao);
?>
<script>
    window.alert("Seu cadastro foi atualizado com sucesso");
    window.location.href = 'index.php';
</script>
<a href="index.php">Voltar</a>