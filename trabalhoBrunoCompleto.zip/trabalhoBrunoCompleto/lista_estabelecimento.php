<html>

<head>

</head>

<body>
    <table>
        <thead>
            <th>ESTABELECIMENETO</th>
            <th>IDENTIFICAÇÃO</th>
            <th>IRREGULARIDADE</th>
            <th>AÇÕES</th>
        </thead>
        <tbody>
            <?php
            include 'conexao.php';

            $selecionar = 'SELECT * FROM estabelecimento';
            $resultado = mysqli_query($conexao, $selecionar) or die('query failed:' . mysqli_error(die));

            while ($linha = mysqli_fetch_array($resultado, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?= $linha["estabelecimentos"] ?></td>
                    <td><?= $linha["identificacao"] ?></td>
                    <td><?= $linha["irregularidade"] ?></td>

                    <td><a href='deletar_estabelecimento.php?id=<?php echo $linha["estabelecimento_id"]?>&action=delete'>DELETAR</a></td>
                    <td><a href='index.php?id=<?php echo $linha["estabelecimento_id"]?>&action=update_estabelecimento'>UPDATE</a></td>
                </tr>
            <?php
            }
            mysqli_close($conexao);
            ?>
        </tbody>

    </table>
</body>

</html>