<?php
include 'conexao.php';

$execultar = 'UPDATE dadosestabelecimento SET razao_soc="' . $_POST["razao_social"] . '",
nome_fant="' . $_POST["nome_fantasia"] . '",
inscricao_mun="' . $_POST["inscricao_municipal"] . '",
inscricao_est="' . $_POST["inscricao_estadual"] . '",
phone="' . $_POST["phone"] . '",
email="' . $_POST["email"] . '" WHERE dadosest_id= ' . $_POST["id"];


$resultado = mysqli_query($conexao, $execultar)
    or die('query failed:' . mysqli_error());

mysqli_close($conexao);

echo "ATUALIZADO COM SUCESSO!!!";
?>
<a href="index.php">Voltar</a>