<html>

<head>

</head>

<body>
    <table>
        <thead>
            <th>RAZÃO SOCIAL</th>
            <th>NOME FANTASIA</th>
            <th>INSCRICAO MUNICIPAL</th>
            <th>INSCRICAO ESTADUAL</th>
            <th>TELEFONE</th>
            <th>EMAIL</th>
            <th>AÇÕES</th>
        </thead>
        <tbody>
            <?php
            include 'conexao.php';

            $selecionar = 'SELECT * FROM dadosestabelecimento';
            $resultado = mysqli_query($conexao, $selecionar) or die('query failed:' . mysqli_error(die));

            while ($linha = mysqli_fetch_array($resultado, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?= $linha["razao_soc"] ?></td>
                    <td><?= $linha["nome_fant"] ?></td>
                    <td><?= $linha["inscricao_mun"] ?></td>
                    <td><?= $linha["inscricao_est"] ?></td>
                    <td><?= $linha["phone"] ?></td>
                    <td><?= $linha["email"] ?></td>
                    

                    <td><a href='deletar_dados_estab.php?id=<?php echo $linha["dadosest_id"]?>&action=delete'>DELETAR</a></td>
                    <td><a href='index.php?id=<?php echo $linha["dadosest_id"]?>&action=update_dados_estab'>UPDATE</a></td>
                </tr>
            <?php
            }
            mysqli_close($conexao);
            ?>
        </tbody>

    </table>
</body>

</html>