<?php
include 'conexao.php';

$execultar = 'UPDATE profissionais SET nome="' . $_POST["nome"] . '",
cpf_prof="' . $_POST["cpf_prof"] . '",
data_nasc="' . $_POST["date"] . '",
fone="' . $_POST["fone"] . '",
email_prof="' . $_POST["email_prof"] . '" WHERE prof_id= ' . $_POST["id"];


$resultado = mysqli_query($conexao, $execultar)
    or die('query failed:' . mysqli_error());

mysqli_close($conexao);

echo "ATUALIZADO COM SUCESSO!!!";
?>
<a href="index.php">Voltar</a>