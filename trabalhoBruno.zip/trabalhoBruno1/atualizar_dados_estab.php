<?php   
    include 'conexao.php';

    $id_dados_estabelecimentos = $_GET["id"];
    $action_dados_estab = "execute-update_dados_estab";

    $select = 'SELECT * FROM dadosestabelecimento WHERE dadosest_id= '.$_GET["id"];
    print_r($select);
    $resultado = mysqli_query($conexao,$select) or die ("query failed:".mysqli_error());

    $coluna = mysqli_fetch_row($resultado);
    mysqli_close($conexao);

    print_r($coluna);

    $razao_soc = $coluna[0];
    $nome_fant = $coluna[1];
    $inscricao_mun = $coluna[2];
    $inscricao_est = $coluna[3];
    $phone = $coluna[4];
    $email = $coluna[5];

?>