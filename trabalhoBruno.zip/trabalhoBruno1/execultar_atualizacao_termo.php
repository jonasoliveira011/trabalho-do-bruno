<?php
include 'conexao.php';

$execultar = 'UPDATE auto_termo SET lei="'.$_POST["lei_base"].'",
classif_lei="'.$_POST["classificacao_lei"].'",
conclusao="'.$_POST["conclusao_pena"].'" WHERE id= '.$_POST["id"];

$resultado = mysqli_query($conexao,$execultar)
or die ('query failed:'.mysqli_error());

mysqli_close($conexao);

echo "ATUALIZADO COM SUCESSO!!!";
?>
<a href="index.php">Voltar</a>