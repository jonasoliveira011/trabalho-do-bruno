<html>

<head>

</head>

<body>
    <table>
        <thead>
            <th>NÍVEL DE RISCO</th>
            <th>DATA MINIMA</th>
            <th>DATA MAXIMA</th>
            <th>COGIDO</th>
            <th>DESCRIÇÃO</th>
            <th>AÇÕES</th>
        </thead>
        <tbody>
            <?php
            include 'conexao.php';

            $selecionar = 'SELECT * FROM nivel_estab';
            $resultado = mysqli_query($conexao, $selecionar) or die('query failed:' . mysqli_error(die));

            while ($linha = mysqli_fetch_array($resultado, MYSQLI_ASSOC)) {
            ?>
                <tr>
                    <td><?= $linha["nivel_risco"] ?></td>
                    <td><?= $linha["data_min"] ?></td>
                    <td><?= $linha["data_max"] ?></td>
                    <td><?= $linha["codigo"] ?></td>
                    <td><?= $linha["descricao_ativ"] ?></td>

                    <td><a href='deletar_nivel.php?id=<?php echo $linha["nivel_id"]?>&action=delete'>DELETAR</a></td>
                    <td><a href='index.php?id=<?php echo $linha["nivel_id"]?>&action=update_nivel'>UPDATE</a></td>
                </tr>
            <?php
            }
            mysqli_close($conexao);
            ?>
        </tbody>

    </table>
</body>

</html>