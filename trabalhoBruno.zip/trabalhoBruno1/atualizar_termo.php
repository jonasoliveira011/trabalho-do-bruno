<?php   
    include 'conexao.php';

    $id_auto_termo = $_GET["id"];
    $action = "execute-update";

    $select = 'SELECT lei,classif_lei,conclusao FROM auto_termo WHERE id= '.$_GET["id"];
    $resultado = mysqli_query($conexao,$select) or die ("query failed:".mysqli_error());

    $coluna = mysqli_fetch_row($resultado);
    mysqli_close($conexao);

    print_r($coluna);

    $lei = $coluna[0];
    $classif_lei = $coluna[1];
    $conclusao = $coluna[2];

?>